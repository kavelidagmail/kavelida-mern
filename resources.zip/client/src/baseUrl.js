const baseUrl = "https://kavelida-simplewebapp.azurewebsites.net";

export default baseUrl;
